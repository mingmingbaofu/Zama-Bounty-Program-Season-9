export async function encryptAmount(amount) {
  // 模拟 FHE 加密逻辑
  return `enc(${amount})`;
}
